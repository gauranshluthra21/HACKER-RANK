'''
Title     : Power - Mod Power
Subdomain : Math
Domain    : Python
Author    : Ahmedur Rahman Shovon
Created   : 15 July 2016
Problem   : https://www.hackerrank.com/challenges/python-power-mod-power/problem
'''
# Enter your code here. Read input from STDIN. Print output to STDOUT
a=int(raw_input())
b=int(raw_input())
c=int(raw_input())
print pow(a,b)
print pow(a,b,c)
