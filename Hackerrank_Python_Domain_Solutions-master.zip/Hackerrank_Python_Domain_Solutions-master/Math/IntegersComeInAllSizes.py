'''
Title     : Integers Come In All Sizes
Subdomain : Math
Domain    : Python
Author    : Ahmedur Rahman Shovon
Created   : 15 July 2016
Problem   : https://www.hackerrank.com/challenges/python-integers-come-in-all-sizes/problem
'''
# Enter your code here. Read input from STDIN. Print output to STDOUT
a=int(raw_input())
b=int(raw_input())
c=int(raw_input())
d=int(raw_input())
print pow(a,b)+pow(c,d)
