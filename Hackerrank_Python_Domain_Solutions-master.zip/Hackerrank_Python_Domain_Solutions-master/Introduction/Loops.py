'''
Title     : Loops
Subdomain : Introduction
Domain    : Python
Author    : Ahmedur Rahman Shovon
Created   : 13 May 2020
Problem   : https://www.hackerrank.com/challenges/python-loops/problem
'''
if __name__ == '__main__':
    n = int(input())
    for i in range(n):
        print(i*i)

