'''
Title     : Say Hello, World! With Python
Subdomain : Introduction
Domain    : Python
Author    : Ahmedur Rahman Shovon
Created   : 23 July 2018
Problem   : https://www.hackerrank.com/challenges/py-hello-world/problem
'''
print("Hello, World!")
