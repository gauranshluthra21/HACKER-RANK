'''
Title     : Arithmetic Operators
Subdomain : Introduction
Domain    : Python
Author    : Ahmedur Rahman Shovon
Created   : 15 April 2020
Problem   : https://www.hackerrank.com/challenges/python-arithmetic-operators/problem
'''
if __name__ == '__main__':
    a = int(input())
    b = int(input())
    print(a+b)
    print(a-b)
    print(a*b)
